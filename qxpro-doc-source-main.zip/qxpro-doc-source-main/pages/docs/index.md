---
home: true
heroImage: /img/logo.png
heroText: 千寻微信框架Pro
tagline: 🚀更好用的PC微信自动化API
actionText: 开始使用 →
actionLink: /doc/start/
bannerBg: none # auto => 网格纹背景(有bodyBgImg时无背景)，默认 | none => 无 | '大图地址' | background: 自定义背景样式       提示：如发现文本颜色不适应你的背景时可以到palette.styl修改$bannerTextColor变量

features: # 可选的
  - title: 解析准确
    details: 全面支持显示、收发emoji符号、微信表情、特殊符号等，支持UTF-8标准编码
  - title: 开发接入
    details: 提供了双向HTTP（支持IPv6）、正向/反向WebSocket开发方式，使用你擅长的编程语言快速接入开发
  - title: 运行稳定
    details: 全新架构，多线程稳定高并发，支持崩溃自动重登，消息发送失败自动重发等机制

# 文章列表显示方式: detailed 默认，显示详细版文章列表（包括作者、分类、标签、摘要、分页等）| simple => 显示简约版文章列表（仅标题和日期）| none 不显示文章列表
postList: none
---

## 🎉支持微信版本
* 3.9.12.54（最新）
* 3.9.12.44
* 3.9.12.16
* 3.9.11.18
* 3.9.10.16
* 3.9.9.34